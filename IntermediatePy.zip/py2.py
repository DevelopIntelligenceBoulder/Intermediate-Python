print('hi')
for num in range(1, 10):
    print(num)

print(5 / 3)
