from collections import namedtuple
Card = namedtuple('Card', 'rank suit')

ranks = [str(rank) for rank in range(2, 11)] + list('JQKA')
suits = 'clubs diamonds hearts spades'.split()
deck = [Card(str(rank), suit) for rank in ranks
                              for suit in suits]
print(deck)
