
import sys

for arg in sys.argv:
  print(arg)
