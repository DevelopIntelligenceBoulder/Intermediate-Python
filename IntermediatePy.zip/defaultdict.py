from collections import defaultdict

count = defaultdict(list)

for line in open('testlist', 'r'):
    wordlist = line.split()
    if len(wordlist) != 2:
        print('skipping malformed line:', line)
    else:
        key, value = wordlist
        print('adding count of', value, 'for key', key)
        count[key].append(value)

from pprint import pprint
pprint(count)
print()

for key in count:
    print('{}: {}'.format(key, count[key]))
