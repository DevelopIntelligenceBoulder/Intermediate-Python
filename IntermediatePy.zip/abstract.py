
class Abstract(object):
    def __init__(self):
        raise TypeError("You can't instantiate this class!")
