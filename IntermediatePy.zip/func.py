def func(x):
  print(x)

import sys
func(sys.argv)
